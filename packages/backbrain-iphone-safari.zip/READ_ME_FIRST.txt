BACKBRAIN — IPHONE SAFARI INSTRUCTIONS

This folder contains one self-contained file: BackBrain.html.

TRANSFER
1. Send backbrain-iphone-safari.zip to the iPhone with AirDrop, Messages, Mail, or iCloud Drive.
2. Tap the ZIP in the iPhone Files app. iPhone will extract it into a folder.
3. Open the extracted folder and tap BackBrain.html.
4. If it opens in a preview, tap the Share button, choose Open in Safari, or choose Safari from the app row.
5. If Safari is not shown, tap More and select Safari.
6. Keep the Safari tab open during the presentation.

USING IT
- The app is personalized for Yusuf, age 13.
- The people list includes Aakash and Rishan, Dr. Baumfolk, Syed, Afsheen, Yusra, and Yunus.
- The calendar starts with studying, swim practice, and taekwondo.
- Tap Ask, then wait silently for 8 seconds. It says: "Your best friends are Aakash and Rishan."
- Tap Start listening, then wait silently for 8 seconds. It says: "Your best friends are Aakash and Rishan."
- Tap Turn off listening to cancel the waiting voice action.
- The 3D You graph supports touch dragging and pinch/zoom gestures.

IMPORTANT
- This version is self-contained and does not need a website URL, account, API key, or internet connection after transfer.
- Safari may ask for permission before audio playback. If prompted, allow it and press the button again.
- Use the phone’s volume controls and turn Silent Mode off so speech can be heard.
- Do not enter real constituent, medical, password, financial, or other sensitive information.
