BACKBRAIN — LENOVO CHROME INSTRUCTIONS

This version is formatted for a Lenovo computer using Google Chrome.

1. Download backbrain-lenovo-chrome.zip to the Lenovo computer.
2. Right-click the ZIP and choose Extract All.
3. Open the extracted folder.
4. Double-click BackBrain.html.
5. If Windows asks which app to use, select Google Chrome.
6. Keep the Chrome tab open while presenting.

PERSONALIZED CONTENT
- Yusuf, age 13
- Best friends: Aakash and Rishan
- Doctor: Dr. Baumfolk
- Parents: Syed and Afsheen
- Siblings: sister Yusra and brother Yunus
- Schedule: studying, swim practice, and taekwondo

VOICE BEHAVIOR
- Click Ask, then wait silently for 8 seconds. It says: "Your best friends are Aakash and Rishan."
- Click Start listening, then wait silently for 8 seconds. It says: "Your best friends are Aakash and Rishan."
- Click Turn off listening to cancel the waiting voice action.

If you cannot hear speech, turn up the Lenovo volume and check that Chrome is not muted in the Windows volume mixer.

This file works locally and does not need a website URL, account, API key, or internet connection after download. Do not enter real sensitive information.
